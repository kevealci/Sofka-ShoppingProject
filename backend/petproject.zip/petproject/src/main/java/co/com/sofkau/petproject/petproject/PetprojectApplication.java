package co.com.sofkau.petproject.petproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetprojectApplication.class, args);
	}

}
