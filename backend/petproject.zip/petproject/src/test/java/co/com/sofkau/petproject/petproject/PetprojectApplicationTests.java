package co.com.sofkau.petproject.petproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
